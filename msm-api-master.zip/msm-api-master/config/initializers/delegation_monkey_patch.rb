module ActiveRecord
  module Delegation
    alias at []
  end
end
