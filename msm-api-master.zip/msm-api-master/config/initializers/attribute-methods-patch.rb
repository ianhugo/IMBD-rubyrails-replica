module ActiveRecord
  module AttributeMethods
    alias fetch []
    alias store []=
  end
end
